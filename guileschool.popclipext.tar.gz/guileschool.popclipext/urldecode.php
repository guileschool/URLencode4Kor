<?php
echo rawurldecode(getenv('POPCLIP_TEXT'));
?>