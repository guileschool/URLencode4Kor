URLencode4Kor (Popclip extension) for MacOS X(한글)
===

Just URL encodes (percent encoding) the selected text using Perl.
